package pknu.it;

public class RestaurantDataBean {
	 private int num;
	 private String id;
	 private String pwd;
	 private String name;
	 private String tel;
	 private String address;
	 private String rclass;
	 private int table;
	 
	 public int getNum() {
		 return num;
	 }
	 public void setNum(int num) {
		 this.num=num;
	 }
	 public String getId() {
	  return id;
	 }
	 public void setId(String id) {
	  this.id = id;
	 }
	 public String getPwd() {
	  return pwd;
	 }
	 public void setPwd(String pwd) {
	  this.pwd =pwd;
	 }
	 public String getName() {
	  return name;
	 }
	 public void setName(String name) {
	  this.name = name;
	 }
	 public String getTel() {
		  return tel;
		 }
	 public void setTel(String tel) {
		  this.tel = tel;
		 }
	 public String getAddress() {
		  return address;
		 }
	 public void setAddress(String address) {
		  this.address = address;
		 }
	 public int getTable() {
		  return table;
		 }
	 public void setTable(int table) {
		  this.table = table;
		 }
	 public String getRclass() {
		  return rclass;
		 }
	 public void setRclass(String rclass) {
		  this.rclass = rclass;
		 }
}
